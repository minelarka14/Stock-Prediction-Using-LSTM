This is created only for the purpose of the open theme badge for scouts. Please read the licence. To use this, please launch
this script in an ide or from your command line. For macOS users, python is preinstalled. For other users, please install
the latest python from https://www.python.org/downloads
